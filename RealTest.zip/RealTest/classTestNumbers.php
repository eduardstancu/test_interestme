<?php


class testNumbers {
    /* We will make a method who give random integer values
    to our two variable that we will return inside an array


    */
    public $myArr = array();
    
    

    public function SelectIntegers(){
        // The method will find two random value
        $this->myArr[0]=rand(1,100);
   
        //print $this->myArr[0];
            
        do {$this->myArr[1]=rand(1,100);}

        while ($this->myArr[1]==$this->myArr[0]);
        // We verify that the two number are different.

        //print "<br>" . $this->myArr[1];

        sort($this->myArr);
        // We sort the arry that the result will be in ascending order
        return $this->myArr;        

    }

    public function loopVariables($a, $b){

        for ($i=$a; $i<=$b; $i++){
            if ($i%3==0){
                echo $i."fizz<br>";
            } elseif($i%5==0){echo $i."buzz<br>";} else {
                echo $i."<br>";
            }
                
        }


    }

    
    
}
?>