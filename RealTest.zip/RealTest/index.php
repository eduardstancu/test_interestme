<?php

require_once("classTestNumbers.php");
// We create an object from the testNumbers class
$myObj = new testNumbers;
$myArr=$myObj->SelectIntegers();
// the method testSelectIntegers return an ordonate array
list($a, $b) = $myArr;
echo "<br>";
echo "The first number is: " . $a . "<br>";
echo "The second number is: " . $b . "<br>";

$myObj->loopVariables($a, $b);
// the method loopVariable loops the values between 
// the two variables and verify the divisibility with 3 and 5
?>