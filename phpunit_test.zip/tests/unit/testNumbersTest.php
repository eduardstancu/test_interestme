<?php 
use PHPUnit\Framework\TestCase;


class testNumbers extends TestCase{
  
    public $myArr = array();
    
    

    public function testSelectIntegers(){
        /* the method create two random variables, put them into an array
        and return it in ordered mode
        */
        /* Other possibility would be to put the creation of the random 
        variables in the construct method of the class
        */
        $this->myArr[0]=rand(1,100);
   
       
            
        do {$this->myArr[1]=rand(1,100);}

        while ($this->myArr[1]==$this->myArr[0]);


       
       // we can verify the assertion that the variable are different.
        $this->assertTrue($this->myArr[1]<>$this->myArr[0]);
        return $this->myArr;
    }
    
    public function testVariableAreIntegers(){
        
        $myArr = self::testSelectIntegers();

        sort($this->myArr);
        // we verify the assertion that our variables are integers
        $this->assertInternalType("int", $this->myArr[0]);
        $this->assertInternalType("int", $this->myArr[1]);
        return $this->myArr;        

    }

    public function testVariableAreNotIntegers(){
        
        $myArr = array('john','doe');

        sort($this->myArr);
        // we verify the assertion that our variables are integers
        $this->assertInternalType("int", $this->myArr[0]);
        
        return $this->myArr;        

    }


    public function loopVariables($a, $b){

        for ($i=$a; $i<=$b; $i++){
            if ($i%3==0){
                echo $i."fizz<br>";
            } elseif($i%5==0){echo $i."buzz<br>";} else {
                echo $i."<br>";
            }
                
        }


    }

    
    
}
?>